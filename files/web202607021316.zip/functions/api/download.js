export async function onRequest(context) {
    const { request } = context;
    
    try {
        const url = new URL(request.url);
        const fileName = url.searchParams.get('file') || 'web.zip';
        const filePath = `/files/${fileName}`;
        
        return new Response(null, {
            status: 302,
            headers: {
                'Location': filePath,
                'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0',
                'Surrogate-Control': 'no-store'
            }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: 'Download failed' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}