export async function onRequest(context) {
    const { request, env } = context;
    const kv = env.VISITOR_KV;

    if (!kv) {
        return new Response(JSON.stringify({ error: 'KV namespace not bound' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const today = new Date().toISOString().split('T')[0];
    const visitorKey = `visitor:${ip}:${today}`;

    const hasVisited = await kv.get(visitorKey);
    let count = parseInt(await kv.get('total_visitors') || '0', 10);

    if (!hasVisited) {
        count++;
        await kv.put('total_visitors', count.toString());
        await kv.put(visitorKey, '1', { expirationTtl: 86400 });
    }

    return new Response(JSON.stringify({ count }), {
        headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-store'
        }
    });
}
