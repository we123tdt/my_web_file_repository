export async function onRequest(context) {
    const { env, request } = context;
    
    try {
        if (!env.VISITOR_KV) {
            return new Response(JSON.stringify({ 
                success: false, 
                error: 'KV namespace not bound',
                fallbackUrl: '/files/web.zip'
            }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        const filesStr = await env.VISITOR_KV.get('download_files');
        
        if (!filesStr) {
            return new Response(JSON.stringify({ 
                success: false, 
                error: 'No files configured in KV',
                fallbackUrl: '/files/web.zip'
            }), {
                status: 404,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        const files = JSON.parse(filesStr);
        
        if (!Array.isArray(files) || files.length === 0) {
            return new Response(JSON.stringify({ 
                success: false, 
                error: 'No files configured',
                fallbackUrl: '/files/web.zip'
            }), {
                status: 404,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        files.sort((a, b) => {
            const getVersion = (name) => {
                const match = name.match(/v(\d+)/);
                if (match) return parseInt(match[1]);
                const dateMatch = name.match(/(\d{4})(\d{2})(\d{2})/);
                if (dateMatch) return parseInt(dateMatch[1] + dateMatch[2] + dateMatch[3]);
                return 0;
            };
            return getVersion(b.name) - getVersion(a.name);
        });
        
        const latest = files[0];
        
        return new Response(JSON.stringify({
            success: true,
            files: files,
            latest: {
                name: latest.name,
                url: `/files/${latest.name}`
            }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ 
            success: false,
            error: error.message,
            fallbackUrl: '/files/web.zip'
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}